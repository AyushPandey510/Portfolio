#!/usr/bin/env bash
# HTTP load tests for Space. Requires: running space-backend on :8080, env.sh with TOK/SID/SESS, oha 1.16.
set -euo pipefail
source env.sh; B=http://127.0.0.1:8080; AUTH="authorization: Bearer $TOK"; mkdir -p raw
run(){ name=$1; shift; oha --no-tui -z 5s -c 64 "$@" >/dev/null 2>&1; oha --no-tui -z 30s -c 64 "$@" > raw/$name.txt 2>&1; }
run health $B/health
run validate -m POST -H "$AUTH" -H 'content-type: application/json' -d "{\"space_id\":\"$SID\",\"latitude\":19.0761,\"longitude\":72.8777,\"accuracy_meters\":12}" $B/geofence/validate
run send_message -m POST -H "$AUTH" -H 'content-type: application/json' -d "{\"session_id\":\"$SESS\",\"content\":\"load test message\"}" $B/spaces/$SID/messages
run list_messages -H "$AUTH" $B/spaces/$SID/messages
run discover_10k -H "$AUTH" "$B/spaces/discover?latitude=19.0760&longitude=72.8777"
# steady-rate latency
oha --no-tui -z 20s -c 32 -q 500 -m POST -H "$AUTH" -H 'content-type: application/json' -d "{\"space_id\":\"$SID\",\"latitude\":19.0761,\"longitude\":72.8777,\"accuracy_meters\":12}" $B/geofence/validate > raw/validate_500rps.txt
oha --no-tui -z 20s -c 32 -q 1000 -m POST -H "$AUTH" -H 'content-type: application/json' -d "{\"session_id\":\"$SESS\",\"content\":\"steady load message\"}" $B/spaces/$SID/messages > raw/send_1000rps.txt
