# Space — how every number was measured

Measured on 1 November 2026 against `AyushPandey510/anonymous` at commit `0207cd3` (`apps/backend`), built with `cargo build --release`.

## Machine (read this before quoting any number)

- Cloud VM: **2 vCPU** Intel Xeon @ 2.10 GHz, **7 GB RAM**, Linux.
- **The server, PostgreSQL 16.15 and the load generator all ran on the same 2 vCPUs.** The load generator competes with the server for CPU, so these are lower bounds; a dedicated server would do better.
- PostgreSQL 16 with default settings except `max_connections=200`. The API uses its own pool of 10 connections (as in the code).
- `RUST_LOG=warn`. No nginx/TLS in front (TLS cost is not included).

## Data set

- 10,001 public Spaces: 10,000 seeded by SQL at random points across Mumbai (lat 18.90–19.25, lon 72.80–73.00, radius 30–300 m), plus one created through the API.
- A real device registration, Space creation and join through the API; that token, Space and session are used by every test.
- By the end of the runs the `messages` table held ~130,000 rows and `location_validation_events` ~83,000 rows; tests ran against that growing data, not an empty database.

## Tools

- HTTP: [oha](https://github.com/hatoo/oha) 1.16.0. Each test = 5 s warm-up (discarded), then 30 s measured, 64 concurrent connections. Steady-rate tests use `-q` (fixed requests/second) with 32 connections for 20 s.
- WebSocket fan-out: `wsbench/` (Rust, tokio-tungstenite). N subscribers open `/ws/spaces/:id`; one sender posts `POST /spaces/:id/messages` at a fixed rate; each message body carries the send time and every subscriber records arrival − send. 200 messages per run (600 for the 60/s run). Note: all subscribers use the same user's token (one session), which the server allows.
- Engine micro-benchmark: a `#[test] #[ignore]` in `src/geofence/mod.rs` calling the real `validate_with_history` 5,000,000 times per run, 5 runs, inputs rotating inside / near boundary / outside. Reported value is the **median of 5 runs**.

## Results

| Test | Result | Raw file |
|---|---|---|
| Geofence engine, one core | median 201 ns per check (~5 M checks/s); runs 160–217 ns | `engine.txt` |
| `GET /health` (framework ceiling) | 83,032 req/s | `raw/health.txt` |
| `POST /geofence/validate`, saturated, 64 conns | 1,241 req/s, 0 errors, p50 50 ms, p99 79 ms (after fix 1) | `raw/validate_fixed.txt` |
| `POST /geofence/validate` at a steady 500 req/s | p50 2.3 ms, p95 9.5 ms, p99 36 ms | `raw/validate_500rps.txt` |
| `POST /spaces/:id/messages`, saturated | 3,072 req/s, p50 20 ms, p99 36 ms | `raw/send_message.txt` |
| `POST /spaces/:id/messages` at a steady 1,000 req/s | p50 1.3 ms, p95 3.1 ms, p99 11 ms | `raw/send_1000rps.txt` |
| `GET /spaces/:id/messages`, saturated | 2,318 req/s, p50 27 ms, p99 41 ms | `raw/list_messages_rerun.txt` |
| `GET /spaces/discover`, 10k Spaces, original code | 80 req/s, p50 813 ms, p99 1,020 ms | `raw/discover_10k.txt` |
| `GET /spaces/discover`, 10k Spaces, with fix 2 | 5,710 req/s, p50 10.8 ms, p99 18 ms (71×) | `raw/discover_10k_bbox.txt` |

WebSocket fan-out, one Space, 20 messages/s (end-to-end = sender's POST to subscriber receiving it):

| Subscribers | Delivered | Deliveries/s | End-to-end p50 | p99 |
|---|---|---|---|---|
| 100 | 100% | 2,009 | 3.6 ms | 6.6 ms |
| 1,000 | 100% | 19,971 | 9.6 ms | 19.6 ms |
| 2,000 | 100% | 39,981 | 14.2 ms | 25.3 ms |
| 4,000 | 100% | 79,860 | 23.8 ms | 50.7 ms |
| 8,000 | 100% | 158,075 | 105 ms | 196 ms |
| 2,000 at 60 msg/s | 100% | 119,502 | 14.3 ms | 43.8 ms |

The knee is between 4,000 and 8,000 subscribers per room on this machine.

## What load testing found (and the local patches in `space-local-changes.diff`)

1. **`POST /geofence/validate` returned 500 on every call.** `effective_lifecycle_state` selects `status` (a Postgres enum) into a Rust `String`; sqlx rejects the decode after the event has been written. Fix: `SELECT status::text, ...` (one line). The first validate run (`raw/validate.txt`) shows the 100%-500 result before the fix.
2. **`GET /spaces/discover` loads every public Space** and filters by distance in Rust, so it slows down linearly with the number of Spaces. Fix: a bounding-box pre-filter on the existing `(latitude, longitude)` index (no Space exceeds 300 m by CHECK constraint). Correctness checked at 5 random points against an independent haversine query in SQL: identical counts.
3. **`GET /spaces/:id/messages` returns the oldest 100 messages** (`ORDER BY created_at ASC LIMIT 100`), so in a busy room new messages never appear in history. Not patched here; the fix is `ORDER BY created_at DESC LIMIT 100` and reversing in the client (or a cursor).
4. Not a performance issue but found while reading the join path: a user with an existing *grace* session is re-activated by `POST /spaces/:id/join` without re-checking location.

Anomaly kept for honesty: the first `list_messages` run (`raw/list_messages.txt`, 38 req/s) ran straight after 92,000 inserts while Postgres was catching up; the isolated re-run is the reported number. The query itself takes 0.65 ms in `EXPLAIN ANALYZE`.

## Reproduce

```
./run_http.sh   # needs oha, a running server and env.sh (TOK, SID, SESS)
./run_ws.sh     # needs wsbench built: cargo build --release in wsbench/
cargo test --release bench_validate_with_history -- --ignored --nocapture
```
