// Fan-out benchmark for Space: N WebSocket subscribers in one Space, one sender
// posting messages over REST at a fixed rate. Each message carries the sender's
// timestamp (micros since start); every subscriber records arrival - sent.
use futures_util::StreamExt;
use hdrhistogram::Histogram;
use std::{env, sync::Arc, time::{Duration, Instant}};

#[tokio::main]
async fn main() {
    let a: Vec<String> = env::args().collect();
    let base = &a[1]; let token = a[2].clone(); let space = &a[3]; let session = a[4].clone();
    let subs: usize = a[5].parse().unwrap(); let msgs: usize = a[6].parse().unwrap(); let rate: u64 = a[7].parse().unwrap();
    let ws_url = format!("{}/ws/spaces/{}", base.replace("http", "ws"), space);
    let start = Instant::now();
    let hist = Arc::new(std::sync::Mutex::new(Histogram::<u64>::new_with_bounds(1, 60_000_000, 3).unwrap()));
    let got = Arc::new(std::sync::atomic::AtomicUsize::new(0));
    let mut handles = vec![];
    for _ in 0..subs {
        let mut req = tokio_tungstenite::tungstenite::client::IntoClientRequest::into_client_request(ws_url.as_str()).unwrap();
        req.headers_mut().insert("Authorization", format!("Bearer {}", token).parse().unwrap());
        let (ws, _) = tokio_tungstenite::connect_async(req).await.expect("ws connect");
        let (_w, mut r) = ws.split();
        let hist = hist.clone(); let got = got.clone();
        handles.push(tokio::spawn(async move {
            while let Some(Ok(m)) = r.next().await {
                if let Ok(t) = m.to_text() {
                    if let Some(i) = t.find("bench:") {
                        let rest = &t[i + 6..];
                        let end = rest.find(|c: char| !c.is_ascii_digit()).unwrap_or(rest.len());
                        let sent: u64 = rest[..end].parse().unwrap_or(0);
                        let now = start.elapsed().as_micros() as u64;
                        hist.lock().unwrap().record(now.saturating_sub(sent).max(1)).ok();
                        got.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
                    }
                }
                if got.load(std::sync::atomic::Ordering::Relaxed) == usize::MAX { break; }
            }
        }));
    }
    eprintln!("connected {} subscribers in {:?}", subs, start.elapsed());
    tokio::time::sleep(Duration::from_millis(500)).await;
    let client = reqwest::Client::new();
    let url = format!("{}/spaces/{}/messages", base, space);
    let mut tick = tokio::time::interval(Duration::from_micros(1_000_000 / rate));
    let send_start = Instant::now();
    let mut post_hist = Histogram::<u64>::new_with_bounds(1, 60_000_000, 3).unwrap();
    for _ in 0..msgs {
        tick.tick().await;
        let sent = start.elapsed().as_micros() as u64;
        let body = serde_json::json!({"session_id": session, "content": format!("bench:{}", sent)});
        let t0 = Instant::now();
        let r = client.post(&url).bearer_auth(&token).json(&body).send().await.unwrap();
        assert!(r.status().is_success(), "post failed {}", r.status());
        post_hist.record(t0.elapsed().as_micros() as u64).ok();
    }
    let send_secs = send_start.elapsed().as_secs_f64();
    let expected = subs * msgs;
    let deadline = Instant::now() + Duration::from_secs(10);
    while got.load(std::sync::atomic::Ordering::Relaxed) < expected && Instant::now() < deadline {
        tokio::time::sleep(Duration::from_millis(50)).await;
    }
    let delivered = got.load(std::sync::atomic::Ordering::Relaxed);
    let total_secs = send_start.elapsed().as_secs_f64();
    for h in handles { h.abort(); }
    tokio::time::sleep(Duration::from_millis(200)).await;
    let h = hist.lock().unwrap();
    println!("subscribers={} messages={} target_rate={}/s sent_in={:.2}s", subs, msgs, rate, send_secs);
    println!("delivered={}/{} ({:.2}%) deliveries_per_sec={:.0}", delivered, expected, 100.0 * delivered as f64 / expected as f64, delivered as f64 / total_secs);
    println!("POST /messages latency ms: p50={:.2} p95={:.2} p99={:.2} max={:.2}", post_hist.value_at_quantile(0.5) as f64/1000.0, post_hist.value_at_quantile(0.95) as f64/1000.0, post_hist.value_at_quantile(0.99) as f64/1000.0, post_hist.max() as f64/1000.0);
    println!("send->receive latency ms: p50={:.2} p95={:.2} p99={:.2} max={:.2}", h.value_at_quantile(0.5) as f64/1000.0, h.value_at_quantile(0.95) as f64/1000.0, h.value_at_quantile(0.99) as f64/1000.0, h.max() as f64/1000.0);
}
