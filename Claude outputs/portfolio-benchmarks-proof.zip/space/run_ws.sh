#!/usr/bin/env bash
# WebSocket fan-out: N subscribers in one Space, 1 sender posting over REST at a fixed rate.
set -euo pipefail
source env.sh; W=./wsbench/target/release/wsbench
for s in 100 1000 2000 4000 8000; do $W http://127.0.0.1:8080 "$TOK" "$SID" "$SESS" $s 200 20 > raw/ws_${s}subs_20mps.txt; done
$W http://127.0.0.1:8080 "$TOK" "$SID" "$SESS" 2000 600 60 > raw/ws_2000subs_60mps.txt
