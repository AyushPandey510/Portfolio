# SwiftShare — how every number was measured

Measured on 1 November 2026 against `AyushPandey510/SwiftShare` (`backend/`, `cargo build --release`), same machine as the Space tests:
**2 vCPU Xeon 2.1 GHz, 7 GB RAM; server and load generator on the same box; loopback network, no TLS.** Lower bounds.

Server started with `PORT=8090 DOWNLOAD_DIR=... DATABASE_PATH=... RUST_LOG=warn`, everything else default (250 MB file limit, LAN discovery running as it does by default).

| Test | Result | Raw file |
|---|---|---|
| `POST /api/upload`, 1 MB random file, 16 concurrent, 30 s after 5 s warm-up | 140 uploads/s (~140 MB/s), 0 errors; p50 51 ms, p95 471 ms, p99 1.2 s | `raw/upload_1mb_c16.txt` |
| `GET /api/file/:code` (metadata lookup by share code), 64 concurrent | 61,220 req/s; p50 0.92 ms, p99 3.3 ms | `raw/lookup_c64.txt` |
| One 200 MB upload, then download (curl, loopback) | upload 0.23 s, download 0.57 s; SHA-256 identical | below |
| Server peak memory (`VmHWM`) across that 200 MB round trip | 11.5 MB at start, 14.9 MB peak: the file is streamed, never held in RAM | below |

Peak memory readings from `/proc/<pid>/status`, fresh server process:
```
start           VmHWM 11492 kB
after upload    VmHWM 14844 kB
after download  VmHWM 14860 kB
```

Notes:
- The upload p95/p99 tail (0.47 s / 1.2 s) is real and worth investigating; likely disk writes under concurrency on this VM.
- `encryption.rs` (AES-256-GCM) exists in the codebase but is **not** called by the upload or download path, so files are stored unencrypted. Don't claim encrypted storage until it is wired in.
